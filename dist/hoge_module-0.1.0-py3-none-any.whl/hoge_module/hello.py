class Hoge:
    def __init__(self):
        print("Hoge.__init__")
    def hello(self):
        print("Hoge.hello")
    def fuga(self):
        print("Hoge.fuga")

